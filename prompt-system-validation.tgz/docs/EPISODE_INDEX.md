# Episode Index

This file is generated from the YAML files in `series/`.

## Welcome to container harbour!

- series id: `container_harbour_series`
- source file: `series/container_harbour_series.yaml`

### Episode 1: What is Kubernetes, really?

- slug: `what-is-kubernetes-really`
- metaphor: a harbor coordinating many containers and ships
- center action: cargo is organized and routed across the harbor

### Episode 2: Pods — Ships in the Harbour

- slug: `pods-ships-in-the-harbour`
- metaphor: pods as grouped units traveling together
- center action: containers are grouped together on the same vessel

### Episode 3: Deployments — Shipping Schedules

- slug: `deployments-shipping-schedules`
- metaphor: deployments as planned recurring shipping operations
- center action: the harbor manager schedules repeated ship departures

### Episode 4: Services — Harbour Traffic Control

- slug: `services-harbour-traffic-control`
- metaphor: services as stable routes directing traffic to the right destination
- center action: incoming cargo is routed to the correct dock

### Episode 5: Ingress — The Harbour Gate

- slug: `ingress-the-harbour-gate`
- metaphor: ingress as the guarded gateway that decides what may enter
- center action: ships are directed through one official harbor entrance

### Episode 6: Autoscaling — Expanding the Fleet

- slug: `autoscaling-expanding-the-fleet`
- metaphor: autoscaling as adding or removing ships depending on demand
- center action: more vessels are called in as harbor traffic increases

### Episode 7: Self-Healing — Repairing the Fleet

- slug: `self-healing-repairing-the-fleet`
- metaphor: self-healing as quickly replacing damaged ships or cargo operations
- center action: a broken vessel is swapped out without stopping the harbor

### Episode 8: Namespaces — Docks Within the Harbour

- slug: `namespaces-docks-within-the-harbour`
- metaphor: namespaces as clearly separated dock zones inside one harbor
- center action: different teams work in separate dock sections without interference

### Episode 9: ConfigMaps — Harbour Notice Boards

- slug: `configmaps-harbour-notice-boards`
- metaphor: shared harbour notice boards displaying operational information for crews
- center action: dock workers read configuration instructions posted on a large harbour notice board

### Episode 10: Secrets — The Captain's Locked Safe

- slug: `secrets-the-captains-locked-safe`
- metaphor: sensitive harbour information stored securely in the captain’s safe
- center action: the harbour captain unlocks a secure safe containing confidential navigation documents

### Episode 11: Volumes — The Cargo Warehouse

- slug: `volumes-the-cargo-warehouse`
- metaphor: cargo warehouses storing goods independently of ships
- center action: containers unload cargo into a dockside warehouse where it remains even if ships leave

### Episode 12: Persistent Volumes — Permanent Harbour Storage

- slug: `persistent-volumes-permanent-harbour-storage`
- metaphor: permanent harbour storage facilities used by many ships
- center action: ships repeatedly load and unload cargo from a large permanent storage facility

### Episode 13: Nodes — The Harbour Piers

- slug: `nodes-the-harbour-piers`
- metaphor: piers where ships dock and operate
- center action: multiple ships dock at different piers where crews unload containers

### Episode 14: Cluster — The Entire Harbour

- slug: `cluster-the-entire-harbour`
- metaphor: the whole harbour system coordinating ships, piers, warehouses, and traffic
- center action: a panoramic view of the harbour showing ships docking, cranes moving cargo, and the harbour master coordinating activity

### Episode 15: Helm — The Harbour Blueprint

- slug: `helm-the-harbour-blueprint`
- metaphor: a blueprint used to quickly construct identical harbour installations
- center action: engineers unroll architectural blueprints showing how to replicate an entire harbour setup

## Like Stories? Love Python!

- series id: `python_story_series`
- source file: `series/python_story_series.yaml`

### Episode 1: Singleton Pattern

- slug: `singleton-pattern`
- metaphor: one unique character controlling access for everyone
- center action: all actors must go through a single gatekeeper

### Episode 2: Factory Pattern

- slug: `factory-pattern`
- metaphor: a producer creating different kinds of actors or props on demand
- center action: a film prop workshop produces different items from one request

### Episode 3: Builder Pattern

- slug: `builder-pattern`
- metaphor: a set being assembled in deliberate stages
- center action: crew members build the scene piece by piece

### Episode 4: Adapter Pattern

- slug: `adapter-pattern`
- metaphor: a translator helping two incompatible systems work together
- center action: a character connects mismatched film equipment so the scene can continue

### Episode 5: Decorator Pattern

- slug: `decorator-pattern`
- metaphor: a plain costume gaining more layers and features
- center action: an actor is progressively enhanced with wardrobe and accessories

### Episode 6: Observer Pattern

- slug: `observer-pattern`
- metaphor: multiple people watching one key event and reacting instantly
- center action: crew members and actors react when a central signal changes

### Episode 7: Strategy Pattern

- slug: `strategy-pattern`
- metaphor: different teams switching tactics to solve the same challenge
- center action: actors test different approaches for filming the same scene

### Episode 8: Command Pattern

- slug: `command-pattern`
- metaphor: instructions packaged and handed off for others to execute
- center action: a director issues action cards that trigger different crew actions

### Episode 9: Facade Pattern

- slug: `facade-pattern`
- metaphor: a single studio front desk simplifying access to many departments
- center action: the presenter uses one reception desk to coordinate lighting, costumes, and props

### Episode 10: Proxy Pattern

- slug: `proxy-pattern`
- metaphor: a stunt double standing in for a movie star
- center action: a stunt performer temporarily replaces the main actor during filming

### Episode 11: Chain of Responsibility Pattern

- slug: `chain-of-responsibility-pattern`
- metaphor: a script request passing through several film crew members until someone handles it
- center action: crew members pass a request along until the right department resolves it

### Episode 12: Mediator Pattern

- slug: `mediator-pattern`
- metaphor: a director coordinating communication between actors and crew
- center action: the director orchestrates interactions so actors do not talk directly to every crew member

### Episode 13: State Pattern

- slug: `state-pattern`
- metaphor: a film set changing behavior depending on whether filming, rehearsing, or resetting
- center action: the crew changes how they behave depending on the current filming state

### Episode 14: Template Method Pattern

- slug: `template-method-pattern`
- metaphor: a standard film production workflow reused across different scenes
- center action: crew follows the same filming sequence but adapts certain steps for each scene

### Episode 15: Visitor Pattern

- slug: `visitor-pattern`
- metaphor: a film critic visiting different departments to analyze their work
- center action: a critic moves between departments evaluating different aspects of the production

